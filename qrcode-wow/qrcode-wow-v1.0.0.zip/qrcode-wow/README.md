# QRCode for WOW
In game QRCode creator for World of Warcraft

## Special Thanks to `luaqrcode`

QRCode-Wow is based on <http://speedata.github.io/luaqrcode/>. 

## Usage

```
/qrcode YOUR MESSAGE
```
